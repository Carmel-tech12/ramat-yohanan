﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data.Odbc;
using System.Data.OleDb;

using System.Data.SqlClient;
using System.Data;
using MSDASC;

using System; 
//using Oracle.DataAccess.Client;
using System.Data.OracleClient;
using System.IO;


namespace UpLoadDataServiceOracle
{
    class ConnectionManager
    {
         private static string m_ConnectionString = string.Empty;
         private static string provider = string.Empty;
        private static void ConenctToDDB()
        {
            try
            {
                if (m_ConnectionString.Length == 0)
                {
                    object _con = null;
                    MSDASC.DataLinks _link = new MSDASC.DataLinks();
                    _con = _link.PromptNew();

                    if (_con != null)
                    {
                        m_ConnectionString = ((ADODB._Connection)_con).ConnectionString;
                    }
                }
                else
                {
                    MSDASC.DataLinks _link = new MSDASC.DataLinks();
                    ADODB.Connection _con = new ADODB.Connection();
                    _con.ConnectionString = m_ConnectionString;
                    object obj = _con;

                    if (_link.PromptEdit(ref obj))
                    {
                        m_ConnectionString = _con.ConnectionString;
                    }
                }
            }
            catch (Exception ex)
            {
                EventManager.WriteEventErrorMessage("SetDataConnection Error", ex);
            }
            finally
            {

            }

        }

        public static string ConnectionString
        {
            get
            {
                ConnectionManager.ConenctToDDB();
                return ConnectionManager.m_ConnectionString;
            }
            set
            {

                ConnectionManager.m_ConnectionString = value;
            }
        }
   

        public static DataSet GetDataForQueries(string command)
        {
            DataSet dataSet = new DataSet();
            string connStr = m_ConnectionString;
              using (OracleConnection connection = new OracleConnection(connStr)) 
            {
                string queryString = command;
                OracleDataAdapter adapter = new OracleDataAdapter(queryString, connStr);
                try
                {
                    connection.Open();
                    adapter.Fill(dataSet);
                }
                catch (Exception ex)
                {
                    EventManager.WriteEventErrorMessage("Error happened while open connection to db", ex);
                }
            }
            return dataSet;
        }

        public static DataSet GetDataForProcedures(string commandName)
        {
            DataSet dataSet = new DataSet();
            string connStr =@""+ m_ConnectionString;
            SqlConnection connection;
            SqlDataAdapter adapter;
            SqlCommand command = new SqlCommand();
            connection = null;
            connection = new SqlConnection(connStr);
            connection.Open();
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = commandName;
            adapter = new SqlDataAdapter(command);
            try
            {
                adapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                EventManager.WriteEventErrorMessage("Error happened while reading data from China", ex);
            }

            connection.Close();

            return dataSet;
        }
        public static DataSet GetDataFromHashODBC(string command)
        {
            string queryString;

            DataSet dataSet = new DataSet();
            int pos = m_ConnectionString.IndexOf("DSN");
            string connStr = m_ConnectionString.Substring(pos, m_ConnectionString.Length - pos - 1);
          
           using (OracleConnection cnn = new OracleConnection(connStr))
            {
                queryString = command;
                OracleDataAdapter adapter = new OracleDataAdapter(queryString, connStr);
               try
                {
                    cnn.Open();
                    adapter.Fill(dataSet);
                }
                catch (Exception ex)
                {
                    EventManager.WriteEventErrorMessage("Error happened while reading data", ex);
                }
            }
            return dataSet;
        }
        //של רמת יוחנן ORACLE פונקציה בדיקה עבור הרצת שאילתה שמתקשרת עם ה
       //לא שימושית בסרוויס
        public static void ConnectOracle()
        {
            string text = "";
            StreamWriter myFile = new StreamWriter(@"C:\Shira-Test\fileq.txt");
            OracleConnection con = new OracleConnection();
            OracleCommand cmd;
            //using connection string attributes to connect to Oracle Database
            con.ConnectionString = "User Id=hofit;Password=ho1234;Data Source=(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.110.248)(PORT = 1521))) (CONNECT_DATA = (SERVICE_NAME = ramaty)))";
            string MyString;

            MyString = "SELECT  a.kod_taktziv ,a.teur ,a.tikrat_ashray ," +
           "(SELECT (2*Sum(b.schum_mdr))  FROM ept07 b" +
                  " WHERE b.conc = a.conc AND b.hevra = a.hevra" +
                  " AND b.shana = '2017'" +
                "  AND hodesh_taktziv = 10" +
                "  AND b.kod_taktziv = a.kod_taktziv " +
                 " AND b.kod_taktziv_neg = 'b2092101')  ," +

       "(SELECT (-1 * Sum(ehz01(d.sug_tnua,d.schum_mdr))) FROM ept07 d" +
                   "    WHERE d.conc = a.conc AND d.hevra = a.hevra AND d.shana = '2017'" +
                     "    AND d.heshbon_taktziv = '1'" +
                      "   AND d.kod_taktziv = a.kod_taktziv" +
                       "  AND d.hodesh_taktziv <=11 ) " +
               " FROM ept01 a WHERE a.conc = 'RAY'";
            cmd = new OracleCommand(MyString, con);
            try
            {
                con.Open();
                text = "done to do ConnectionString";
              //  System.IO.File.WriteAllText(@"C:\Shira-Test\WriteText.txt", text);
              //  System.IO.File.WriteAllText(@"C:\Shira-Test\WriteText2.txt", MyString);

                try
                {
                    OracleDataReader reader = cmd.ExecuteReader();
                    myFile.WriteLine("the FieldCount is:" + reader.FieldCount);
                    myFile.WriteLine("the reader.Read is:" + reader.Read());
                    while (reader.Read())
                    {
                        // System.IO.File.WriteAllText(@"C:\Shira-Test\Write.txt",reader.GetTextReader(1).ToString());
                        //  myFile.WriteLine(String.Format("kod_taktziv {0} teur {1} ", reader["kod_taktziv"], reader["teur"]), false);
                        myFile.WriteLine(String.Format("kod_taktziv {0} teur {1}", reader["kod_taktziv"]), false);
                    }
                    reader.Close();
                    myFile.Close();
                }
                catch (Exception e)
                {
                    myFile.WriteLine("error:" + e);
                    myFile.Close();
                    con.Close();
                }
            }
            catch (Exception e)
            {
                text = "failed to do ConnectionString";
            }
            con.Close();
            con.Dispose();
            Console.WriteLine("Disconnected");
        }
    }
}
